PHP Platform SDK 
===================

Thank you for using the PayPal Platform SDK for PHP.

DOCUMENTATION
=============
The SDK Installation Guide is located under the �Docs� folder in the SDK root directory. 
The AdaptivePayments and AdaptiveAccounts API 

LICENSING
=========
Read the "LICENSE.txt" under the licenses directory file for important legal information regarding the PayPal SDK.

================================
Copyright (c) 2009 PayPal, Inc.
