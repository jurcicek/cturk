<?php

/******************************************************
PreapprovalDetails.php

This page is specified as the ReturnURL for the Preapproval Operation.
When returned from PayPal this page is called.
Page get the payment details for the preapprovalKey either stored
in the session or passed in the Request.

******************************************************/

require_once '../../Lib/Config/Config.php';
require_once '../../Lib/CallerService.php';
require_once '../Common/NVP_SampleConstants.php';

session_start();
	
	if(isset($_GET['cs'])) {
		$_SESSION['preapprovalKey'] = '';
	}

	try {
			if(isset($_REQUEST["preapprovalKey"])){
			$preapprovalKey = $_REQUEST["preapprovalKey"];
			}
			if(empty($preapprovalKey))
			{
				$preapprovalKey = $_SESSION['preapprovalKey'];
			}
			
			$request_array= array (
			PreapprovalDetail::$preapprovalKey=> $preapprovalKey,
			RequestEnvelope::$requestEnvelopeErrorLanguage => 'en_US'
			);
			
		
			$nvpStr=http_build_query($request_array);
		    $resArray=hash_call("AdaptivePayments/PreapprovalDetails",$nvpStr);
		           
			
			
			/* Display the API response back to the browser.
			   If the response from PayPal was a success, display the response parameters'
			   If the response was an error, display the errors received using APIError.php.
			*/
		$ack = strtoupper($resArray["responseEnvelope.ack"]);
		  if($ack!="SUCCESS"){
			$_SESSION['reshash']=$resArray;
			$location = "APIError.php";
			header("Location: $location");
 
			}
	}
	catch(Exception $ex) {

	throw new Exception('Error occurred in PaymentDetails method');
	}
?>

<html >
<head >
    <title>Preapproval Detail </title>
    <link href="../Common/style.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="../Common/tooltip.js">
    </script>
</head>
<body >
		<?php 
require_once '../Common/menu.html';?>
   

<center>
    <font size="2" color="black" face="Verdana"><b>Preapproval
    Details</b></font><br>
    <br>

        
 		
 		<table  width=400 >
 		 <?php echo "<tr><td>PreapprovalKey : ".$preapprovalKey;
 		 ?>
 		  		 </table>
 		<?php 
 		 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
</center>
</body>
</html>







