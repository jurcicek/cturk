

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
<HEAD>
<title>PayPal SDK - Adaptive Payments - Execute Payment Option</title>
<link href="../Common/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../Common/tooltip.js">
    </script>
</HEAD>

<script type="text/javascript">
function PrePopulate()
{
	document.getElementById('payKey').value = "";
}


</script>
<body >
		<?php 
require_once '../Common/menu.html';?>
<center>
<form action="ExecutePaymentOptionReceipt.php">
	<table class="api" align="center">
		<tr>
			<td colspan="3" class="header" width= "408px" align="center"><b>Adaptive Payments - Execute Payment Option</td>
		</tr>
	</table>
	<br><br>
	<table>
		<tr align="right">
			<td><input type="button" value="Populate default values" onclick="PrePopulate()"
				STYLE="background-color: #98AFC7; width: 20em;"></td>
		</tr>
	</table>

	<table>

		<tr>
			<td class="thinfield" width="80"><a href=""
				style="text-decoration: none"
				onmouseover="ShowContent('PayKey'); return true;"
				onmouseout="HideContent('PayKey'); return true;"
				href="javascript:ShowContent('PayKey')">Pay Key:</a>
			<div id="PayKey"
				style="display: none; position: absolute; border-style: solid; background-color: white; padding: 20px;">The pay key that identifies the payment to be executed. <br />This is the
                    pay key returned in the PayResponse message of PAY api with CREATE option</div>
			</td>
			<td align="left"><input id="payKey" type="text" maxLength="32"
				size="60" value="<?php echo $_GET["payKey"];?>" name="payKey"></td>
		</tr>

		<TR>

			<td colspan="2">
			<center><input type="Submit" value="ExecutePayOption"
				id="Submit" name="Submit"></center>
			</td>
		</TR>
	</table>
</form>
</center>
</body>
</HTML>
