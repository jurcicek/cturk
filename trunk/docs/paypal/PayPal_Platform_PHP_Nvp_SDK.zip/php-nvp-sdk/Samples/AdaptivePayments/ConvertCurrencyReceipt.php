<?php

/******************************************************
ConvertCurrencyReceipt.php
Displays the Currency conversion details after calling the
ConvertCurrency API.
Called by SetConvertCurrency.php 
Calls  AdaptivePayments.php,and APIError.php.
******************************************************/

require_once '../../Lib/Config/Config.php';
require_once '../../Lib/CallerService.php';
require_once '../Common/NVP_SampleConstants.php';
session_start();

	try {
		$request_array= array(
		ConvertCurrency::$baseAmountList_currency_0_amount => $_REQUEST['baseamount'],
		ConvertCurrency::$baseAmountList_currency_0_code  =>  $_REQUEST['fromcurrencyCode'],
		ConvertCurrency::$convertToCurrencyList_currencyCode_0 =>  $_REQUEST['tocurrencyCode1'],
		ConvertCurrency::$convertToCurrencyList_currencyCode_1 =>  $_REQUEST['tocurrencyCode2'],
		ConvertCurrency::$convertToCurrencyList_currencyCode_2 =>  $_REQUEST['tocurrencyCode3'],
		RequestEnvelope::$requestEnvelopeErrorLanguage => 'en_US'
		);
		
		
		$nvpStr=http_build_query($request_array);
		$resArray=hash_call('AdaptivePayments/ConvertCurrency',$nvpStr);
		
		/* Display the API response back to the browser.
		   If the response from PayPal was a success, display the response parameters'
		   If the response was an error, display the errors received using APIError.php.
		*/
	$ack = strtoupper($resArray['responseEnvelope.ack']);
		if($ack!="SUCCESS"){
		$_SESSION['reshash']=$resArray;
		$location = "APIError.php";
		header("Location: $location");
			}
		}
		catch(Exception $ex) {
			
		throw new Exception('Error occurred in PaymentDetails method');
		}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
  <meta name="generator" content=
  "HTML Tidy for Windows (vers 14 February 2006), see www.w3.org">

  <title>PayPal PHP SDK -Payment Details</title>
 <link href="../Common/style.css" rel="stylesheet" type="text/css" />
</head>

<body >
		<?php 
require_once '../Common/menu.html';?>
  <center>
    <font size="2" color="black" face="Verdana"><b>Currency Conversion
    Details</b></font><br>
    <br>

    <table width="400">
	
		 <?php 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
	</table>
	 </center>
</body>
</html>