<?php

/********************************************
 SetPaymentOptionReceipt.php

 This file is called after the user clicks on a button during
 the Pay process to use PayPal's AdaptivePayments Pay features'. The
 user logs in to their PayPal account.
 Called by SetPaymentOption.php
 Calls  CallerService.php,and APIError.php.
 ********************************************/

require_once '../../Lib/Config/Config.php';
require_once '../../Lib/CallerService.php';
require_once '../Common/NVP_SampleConstants.php';
session_start();

try {

		$request_array= array(
			
			SetPaymentOption::$payKey => $_REQUEST["payKey"],
		    RequestEnvelope::$requestEnvelopeErrorLanguage => 'en_US'
			);
			if($_REQUEST['headerImage'])
			{
				$request_array[SetPaymentOption::$displayOptions_emailHeaderImageUrl] =  $_REQUEST['headerImage'];
			}
			if($_REQUEST['marketingImage'])
			{
				$request_array[SetPaymentOption::$displayOptions_emailMarketingImageUrl] =  $_REQUEST['marketingImage'];
			}
					
	$nvpStr=http_build_query($request_array);
	$resArray=hash_call('AdaptivePayments/SetPaymentOptions',$nvpStr); 

	
		
	/* Make the call to PayPal to get the Pay token
	 If the API call succeded, then redirect the buyer to PayPal
	 to begin to authorize payment.  If an error occured, show the
	 resulting errors
	 */
	
         
		$ack = strtoupper($resArray['responseEnvelope.ack']);

	if($ack!="SUCCESS"){
		$_SESSION['reshash']=$resArray;
		$location = "APIError.php";
		header("Location: $location");
			}
		}
		catch(Exception $ex) {
			
		throw new Exception('Error occurred in PaymentDetails method');
		}
	
				?>
<html>
<head>

<title>PayPal Platform SDK - Set Payment Option</title>
<link href="../Common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >
		<?php 
require_once '../Common/menu.html';?>
   


<center><b><u></u></b> <br />
<font size=2 color=black face=Verdana><b>Set Payment Options - Response</b></font>
<br />
<br />

<table>
	 <?php 
   		 	require_once 'ShowAllResponse.php';
   		 	$payKey=$_REQUEST["payKey"];
   		 	echo"<a href=ExecutePaymentOption.php?payKey=$payKey><b>* Execute Payment Options</b></a><br>";
   		 ?>
</table>
<br />

</center>


</body>
</html>

			