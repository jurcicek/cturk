<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>PayPal SDK - Adaptive Payments CancelPreapproval</title>
		 <link href="../Common/style.css" rel="stylesheet" type="text/css" />
		 <script type="text/javascript" src="../Common/tooltip.js">
    </script>
	</HEAD>
<script type="text/javascript">
function prefill()
{
	document.getElementById('preapprovalKey').value = "PA-1B596337Y5206552R";

}






</script>

<body >
	<?php 
require_once '../Common/menu.html';?>
		<form id="Form1" method="post"action = "CancelPreapprovalReceipt.php?cs=s">
			<center>
				<font  class="header"   width= "408px" align="center"><b>Adaptive Payments -CancelPreapproval</b></font><br>
				<br>
					<table>
					<tr>
		<td colspan="2">
		<center><br>
		You must be logged into <a href="https://sandbox.paypal.com"
			id="PayPalDeveloperCentralLink" target="_blank"
			name="PayPalDeveloperCentralLink">Developer Central<br>
		</a><br>
		</center>
		</td>
	</tr>
						<tr align="right">
							<td><input type= "button" value="Populate default values" onclick="prefill()" STYLE="background-color:#98AFC7;width: 20em;" ></td>
						</tr>
					</table>
				<table width="600">
					<tr>
						<td width="120"><a href= "" style="text-decoration:none" onmouseover="ShowContent('preaproovalKey'); return true;"onmouseout="HideContent('preaproovalKey'); return true;"href="javascript:ShowContent('preaproovalKey')">Pre Approval Key:</a>
<div id="preaproovalKey" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;"> The preapproval key that identifies the preapproval to be canceled..</div>
</td>
						<td><input type="text" name="preapprovalKey" id="preapprovalKey" size="50" value=""></td>
					</tr>
					
					<tr>
						<td class="thinfield" width="52"></td>
							<td class="thinfield" width="52"><input type="submit" value="Submit" id="Submit" NAME="Submit"></td>

					</tr>
				</table>
			</center>
			
		</form>
	</body>
</HTML>
