<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>PayPal PHP SDK -Preapproval Details</title>
		 <link href="../Common/style.css" rel="stylesheet" type="text/css" />
		 <script type="text/javascript" src="../Common/tooltip.js">
    </script>
	</HEAD>
<script type="text/javascript">
function prefill()
{
	document.getElementById('payKey').value = "AP-5YL76254522892258";

}






</script>

		<body >
		<?php 
require_once '../Common/menu.html';?>
<center>

		<form id="Form1" method="post" action="PaymentDetails.php?cs=s">
	<table class="wwFormTable">

		<tr>
			<td colspan="3" class="header" style="width: 408px" align="center">
			<div class="header"><b>Adaptive Payments - PaymentDetails</b></div>
			</td>
		</tr>
	</table>
	<br>
<br>
	<table>
		<tr align="right">
			<td>
			<input type= "button" value="Populate Default Values &darr;" onclick="prefill()" STYLE="background-color:#98AFC7;width: 20em;" />
			</td>
		</tr>
	</table>
	<table width="600">
		<tr>

			<td width="80"><a style="text-decoration: none"
				onmouseover="ShowContent('payKey1'); return true;"
				onmouseout="HideContent('payKey1'); return true;"
				href="javascript:ShowContent('payKey1')">Pay Key:</a>
			<div id="payKey1"
				style="display: none; position: absolute; border-style: solid; background-color: white; padding: 20px;">The
			 The pay key that identifies the payment for which you want to
                    retrieve details. <br />This is the pay key returned in the PayResponse message</div>
			</td>
			<td><input type="text" name="payKey" id="payKey" size=55" 	value=""></td>
		</tr>

		<tr>
			<td class="thinfield" width="52"></td>

			<td class="thinfield" width="52"><input type="submit"
				value="Submit" id="Submit" NAME="Submit"></td>

		</tr>
	</table>
	</form>




	</center>
	
</body>

</HTML>

