<?php

/******************************************************
CancelPreapprovalReceipt.php

Page get the preapprovalKey either stored
in the session or passed in the Request.

******************************************************/

require_once '../../Lib/Config/Config.php';
require_once '../../Lib/CallerService.php';
require_once '../Common/NVP_SampleConstants.php';
session_start();

	if(isset($_GET['cs'])) {
		$_SESSION['preapprovalKey'] = '';
	}
	try {
		
		$preapprovalKey = $_REQUEST["preapprovalKey"];
		if(empty($preapprovalKey))
		{
			$preapprovalKey = $_SESSION['preapprovalKey'];
		}
		
	$request_array= array(
	CancelPreapproval::$preapprovalKey => $preapprovalKey,
	RequestEnvelope::$requestEnvelopeErrorLanguage => 'en_US'
	);
	
	
	$nvpStr=http_build_query($request_array);
	$resArray=hash_call('AdaptivePayments/CancelPreapproval',$nvpStr);
		
		
		/* Display the API response back to the browser.
		   If the response from PayPal was a success, display the response parameters'
		   If the response was an error, display the errors received using APIError.php.
		*/
	          
		$ack = strtoupper($resArray['responseEnvelope.ack']);

	if($ack!="SUCCESS"){
		$_SESSION['reshash']=$resArray;
		$location = "APIError.php";
		header("Location: $location");
			}
		}
		catch(Exception $ex) {
			
		throw new Exception('Error occurred in PaymentDetails method');
		}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
  <meta name="generator" content=
  "HTML Tidy for Windows (vers 14 February 2006), see www.w3.org">

  <title>PayPal PHP SDK -Payment Details</title>
<link href="../Common/style.css" rel="stylesheet" type="text/css" />
</head>

<body bgcolor= "#E6EAE9">
<body >
		<?php 
require_once '../Common/menu.html';?>
  <center>
    <font size="2" color="black" face="Verdana"><b>Cancel Preapproval
    </b></font><br>
    <br>

    <table width="400">
		
		 <?php 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
    </table>
  </center>
</body>
</html>