<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>PayPal SDK - Adaptive Payments - Refund</title>
		<link href="../Common/style.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="../Common/tooltip.js">
    </script>
	</HEAD>
<script type="text/javascript">
function prefill()
{
	document.getElementById('payKey').value = "";
	document.getElementById('receiveremail').value = "platfo_1255611349_biz@gmail.com";
	document.getElementById('amount').value = "1.00";
}


</script>

	<body >
		<?php 
require_once '../Common/menu.html';?>
   
		<form id="Form1" method="post" action ="RefundReceipt.php">
			<center>
				<table class="api">
					<tr>
						<td colspan="2" class="header"width= "408px" align="center"><b>Adaptive Payments - Refund</b></td>
					</tr>
				</table>
				<br><br>
					<table>
						<tr align="right">
							<td><input type= "button" value="Populate default values" onclick="prefill()" STYLE="background-color:#98AFC7;width: 20em;" ></td>
						</tr>
					</table>
				<table>
					<tr>
						<td class="thinfield"><a href= "" style="text-decoration:none" onmouseover="ShowContent('paykey'); return true;"onmouseout="HideContent('paykey'); return true;"href="javascript:ShowContent('paykey')">Pay Key:</a>
							<div id="paykey" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">The key used to create the payment that you want to refund.</div>
						</td>
						<td><input type="text" maxlength="32" name="payKey" id="payKey" size="40"></td>
					</tr>
					<tr>
						<td class="thinfield" width="52">
							<a href= "" style="text-decoration:none" onmouseover="ShowContent('currencycode'); return true;"onmouseout="HideContent('currencycode'); return true;"href="javascript:ShowContent('currencycode')">currencyCode</a>
								
							<div id="currencycode" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">The currency code. If specified, you must specify the currency code
							that matches the currency code of the original payment</div>	
							</td>
						<td><select name="currencyCode" id="currencyCode">
								<option value="USD" selected>USD</option>
								<option value="GBP">GBP</option>
								<option value="EUR">EUR</option>
								<option value="JPY">JPY</option>
								<option value="CAD">CAD</option>
								<option value="AUD">AUD</option>
							</select></td>
					</tr>

					<tr>
					</tr>
					<TR>
							<td class="thinfield" height="14" colspan="4" bgcolor="#41627E">
								<p align="center">
									<b>Refund Details</b></p>
							</td>
					</TR>
					<tr>
						<td width="52"><a href= "" style="text-decoration:none" onmouseover="ShowContent('receivers'); return true;"onmouseout="HideContent('receivers'); return true;"href="javascript:ShowContent('receivers')">Receivers</a>
							<div id="receivers" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">Information about the receivers of the payment that you want to
							refund</div>
						</td>
						<td><a href= "" style="text-decoration:none" onmouseover="ShowContent('receiverEmail1'); return true;"onmouseout="HideContent('receiverEmail1'); return true;"href="javascript:ShowContent('receiverEmail1')">ReceiverEmail (Required):</a>
							<div id="receiverEmail1" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">receiver's Email</div>	
						</td>
						<td><a href= "" style="text-decoration:none" onmouseover="ShowContent('amount'); return true;"onmouseout="HideContent('amount'); return true;"href="javascript:ShowContent('amount')">Amount(Required):</a>
						<div id="
" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">
 to refund; not to exceed the amount of the payment</div>	

						</td>
					</tr>
					<tr>
						<td>
							<P align="left">1</P>
						</td>
						<td><input type="text" name="receiveremail" id="receiveremail" size="50" value=""></td>
						<td><input type="text" name="amount" id="amount" size="5" maxlength="7" value=""></td>
					</tr>

					
						
					<tr>
						<td class="thinfield" width="52"></td>
						<td class="thinfield" width="52"><input type="submit" value="Submit" id="Submit"></td>
					</tr>
				</table>
			</center>
		
		</form>
	</body>
</HTML>