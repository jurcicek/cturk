

<html >
<head >
    <title>Preapproval Detail </title>
     <link href="../Common/style.css" rel="stylesheet" type="text/css" />
     <script type="text/javascript" src="../Common/tooltip.js">
    </script>
</head>

<script type="text/javascript">
function prefill()
{
	document.getElementById('txtPayKey').value = "AP-9WL98812NG3305646";

}


</script>

<body >
		<?php 
require_once '../Common/menu.html';?>
</div>
   
    <form id="form1" action = "PreapprovalDetails.php?cs=s">
    <table align="center">
            <tr>
				<td colspan="3" class="header" width= "408px" align="center"><b>Adaptive Payments - Preapproval Details</b></td>
			</tr>
			</table>
			<br>
		<table align="center">	
				<tr align="center">
						<br><td><input type= "button" value="Poppulate Default Values" onclick="prefill()" STYLE="background-color:#98AFC7;width: 15em;" ></td>
				</tr>
			</table>
        <table align="center">
            <tr>
                
            </tr>
            <tr>
                <td style="width: 120px">
                   <a href= "" style="text-decoration:none" onmouseover="ShowContent('preaproovalKey'); return true;"onmouseout="HideContent('preaproovalKey'); return true;"href="javascript:ShowContent('preaproovalKey')"> 
                        Preapproval Key
                   </a>
                  <div id="preaproovalKey" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">The pay key that identifies the payment for which you want to
                    retrieve details. <br />This is the pay key returned in the PayResponse message.</div>
                </td>
                <td style="width: 100px">
                    <input type ="text" id="txtPayKey" name= "preapprovalKey" size="50" /></td>
               
            </tr>
            <tr>
                <td style="width: 100px">
                </td>
                <td style="width: 100px">
                    &nbsp;<input id="Submit1"  type="submit" 
                        value="Submit" /></td>
                <td style="width: 100px">
                </td>
            </tr>
        </table>
    
    </form>
</body>
</html>
