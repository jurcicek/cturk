
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
<HEAD>
<title>PayPal SDK - Adaptive Payments - Get Payment Option</title>
<link href="../Common/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../Common/tooltip.js">
    </script>
</HEAD>

<script type="text/javascript">
function PrePopulate()
{
	document.getElementById('payKey').value = "AP-5YL76254522892258";
}


</script>
<body >
		<?php 
require_once '../Common/menu.html';?>
</div>
<center>
<form action="GetPaymentOptionReceipt.php">
	<table class="api" align="center">
		<tr>
			<td colspan="3" class="header" width= "408px" align="center"><b>Adaptive Payments - Get Payment Option</b></td>
		</tr>
	</table>
	<br><br>
	<table>
		<tr align="right">
			<td><input type="button" value="Populate default Values" onclick="PrePopulate()"
				STYLE="background-color: #98AFC7; width: 20em;"></td>
		</tr>
	</table>

	<table>

		<tr>
			<td class="thinfield" width="80"><a href=""
				style="text-decoration: none"
				onmouseover="ShowContent('PayKey1'); return true;"
				onmouseout="HideContent('PayKey1'); return true;"
				href="javascript:ShowContent('PayKey1')">Pay Key:</a>
			<div id="PayKey1"
				style="display: none;width:200px; position: absolute; border-style: solid; background-color: white; padding: 20px;">The pay key that identifies the payment for which you want to set
                    payment options.<br /> This is the pay key returned in the PayResponse message.</div>
			</td>
			<td align="left"><input id="payKey" type="text" maxLength="32"
				size="60" value="" name="payKey"></td>
		</tr>

		<TR>

			<td colspan="2">
			<center><input type="Submit" value="GetPayOption"
				id="Submit" name="Submit"></center>
			</td>
		</TR>
	</table>
</form>
</center>
</body>
</HTML>
