<?php

/********************************************
RefundReceipt.php
Displays refund status after calling Refund API
Called by Refund.php
Calls  AdaptivePayments.php,and APIError.php.
********************************************/

require_once '../../Lib/Config/Config.php';
require_once '../../Lib/CallerService.php';
require_once '../Common/NVP_SampleConstants.php';
session_start();
		try {

			
			$request_array= array(
			Refund::$currencyCode => $_REQUEST["currencyCode"],
			Refund::$payKey  => $_REQUEST["payKey"],
			Refund::$receiverList_receiver_0_amount => $_REQUEST["amount"],
			Refund::$receiverList_receiver_0_email => $_REQUEST["receiveremail"],
			RequestEnvelope::$requestEnvelopeErrorLanguage => 'en_US'
			);
			
	$nvpStr=http_build_query($request_array);
	$resArray=hash_call('AdaptivePayments/Refund',$nvpStr);
			
	       /* Make the call to PayPal to get the Pay token
	        If the API call succeded, then redirect the buyer to PayPal
	        to begin to authorize payment.  If an error occured, show the
	        resulting errors
	        */
	      
	           
		$ack = strtoupper($resArray['responseEnvelope.ack']);

	if($ack!="SUCCESS"){
		$_SESSION['reshash']=$resArray;
		$location = "APIError.php";
		header("Location: $location");
			}
		}
		catch(Exception $ex) {
			
		throw new Exception('Error occurred in PaymentDetails method');
		}
?>
<html>
<head>
    <title>PayPal PHP SDK - AdaptivePayments Refund</title>
   <link href="../Common/style.css" rel="stylesheet" type="text/css" />
</head>
<body >
		<?php 
require_once '../Common/menu.html';?>

    <center>
     <b>Refund details!</b><br><br>
    <table width=400>
       <?php 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
    </table>
    </center>
    
</body>
</html>