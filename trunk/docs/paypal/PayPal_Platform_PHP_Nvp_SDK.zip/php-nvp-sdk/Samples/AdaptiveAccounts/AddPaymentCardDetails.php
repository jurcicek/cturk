<?php

/********************************************
AddPaymentCarddetail.php
Calls AddPaymentCard API of CreateAccounts webservices.

Called by AddPaymentCardReceipt.php
Calls  AdaptiveAccounts.php,and APIError.php.
********************************************/


session_start();
$resArray = $_SESSION['cardAdded'];  
     
?>
<html>
 <link href="../Common/style.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" src="../Common/tooltip.js">
    </script>
<body>
<center><font size=2 color=black face=Verdana><b>AddPaymentCard (as funding source) Confirmation</b></font> <br>
<br>
<b>Card Added!</b><br>
<br>
<?php 
require_once '../Common/menu.html';?>
<table width=400>
 


        
 		<?php 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
</table>

</center>

</body>
</html>