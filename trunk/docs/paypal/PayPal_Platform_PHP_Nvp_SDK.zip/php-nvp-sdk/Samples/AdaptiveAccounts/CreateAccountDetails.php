<?php

/********************************************
CreateAccountdetail.php
Calls CreateAccount API of CreateAccounts webservices.

Called by CreateAccountReceipt.php
Calls  AdaptiveAccounts.php,and APIError.php.
********************************************/


session_start();
$resArray  = $_SESSION['AccountCreated'];       
?>
<html>
 <link href="../Common/style.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" src="../Common/tooltip.js">
    </script>
<body>
<center><font size=2 color=black face=Verdana><b>Account Creation Confirmation</b></font> <br>
<br>
<b>Account Created!</b><br>
<br>
<?php 
require_once '../Common/menu.html';?>
<table width=400>
 


        
 		<?php 
   		 	require_once 'ShowAllResponse.php';
   		 ?>
</table>

</center>

</body>
</html>