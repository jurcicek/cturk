<?php

/********************************************
SetFundingSourceConfirmed.php


Calls  SetFundingSourceConfirmedReceipt.php,and APIError.php.
********************************************/

?>

<html>
<head>
    <title>Adaptive Accounts - Set Funding Source Confirm Page</title>
    <link href="../Common/style.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" src="../Common/tooltip.js">
</script>
</head>
<script type="text/javascript">
function prefill()
{
	document.getElementById('emailAddress').value = "platfo@paypal.com";
}
</script>
<script type="text/javascript" src="../ToolTip.js">
</script>
<body bgcolor= "#E6EAE9">
<?php 
require_once '../Common/menu.html';?>
    <form id="form1" action ="SetFundingSourceConfirmedReceipt.php">
        <table align="center">
			<tr>
				<td colspan="3" class="header" style="width: 408px" align="center">
				    <div class="header"><b>Adaptive Accounts - Set Funding Source Confirm</b></div>
				</td>
			</tr>
			<tr>
				<td colspan="3">
				<center>
					<br />
						You must be logged into <a href="https://developer.paypal.com" id="PayPalDeveloperCentralLink" target="_blank"
						name="PayPalDeveloperCentralLink" class="devcentral"><font color="blue">Developer Central</font><br />
						</a>
					<br />
				</center>
					</td>
			</tr>
		</table>
		<table align="center">
			<tr align="right">
				<td><input type= "button" value="Populate Default Values " onclick="prefill()" style="background-color:#98AFC7;width: 20em;" /></td>
			</tr>
		</table>

        <table align="center">
            <tr>
                <td style="width:200px">
                <a style="text-decoration:none" onmouseover="ShowContent('email'); return true;"onmouseout="HideContent('email'); return true;"href="javascript:ShowContent('email')">
                    email Id: </a>
                <div id="email" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">The email address for the bank</div>                  
                </td>
                 <td align="left" style="width: 408px">
                     <input type="text" id="emailAddress" name="emailAddress"  size="50"/>
                </td>
            </tr>
            <tr>
                <td style="width:200px">
                <a style="text-decoration:none" onmouseover="ShowContent('fundinSourceKey'); return true;"onmouseout="HideContent('fundinSourceKey'); return true;"href="javascript:ShowContent('fundinSourceKey')">
                   Funding Source Key: </a>
                <div id="fundinSourceKey" style="display:none; position:absolute; border-style: solid; background-color: white; padding: 20px;">Key generated from Create account web flow</div>                  
                </td>
                 <td align="left" style="width: 408px">
                     <input type="text" id="fundingSourceKey" name="fundingSourceKey"  size="50"/>
                </td>
            </tr>            
            <tr></tr>
            <tr>
                <td></td>
                <td class="thinfield" style="width: 408px">
                    <input id="Submit1" name="submit" type="submit" value="Submit" onserverclick="Submit1_ServerClick" /></td>
            </tr>
        </table>
    </form>
</body>
</html>

