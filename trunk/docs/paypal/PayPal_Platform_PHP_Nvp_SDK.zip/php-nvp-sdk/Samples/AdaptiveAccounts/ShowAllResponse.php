<html>

  <table  width=400>
	        	<?php 
    		foreach($resArray as $key => $value) {
    			
    			echo "<tr><td> $key:</td><td>$value</td>";
    			}	
       			?>
  </table>
</html>